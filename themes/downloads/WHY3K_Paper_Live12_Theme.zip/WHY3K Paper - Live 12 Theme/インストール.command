#!/bin/bash
# WHY3K テーマを、この Mac に入っている Ableton Live 全部にインストールする。
# Live をアップデートするとテーマは消えるので、そのたびにこれを実行すればいい。
#
# ダブルクリックで「アクセス権がありません」と言われる場合は、ターミナルにこの1行を貼る：
#   bash "$HOME/Library/CloudStorage/GoogleDrive-t.kobays29@gmail.com/マイドライブ/Abletonテーマ/インストール.command"
cd "$(dirname "$0")" || exit 1

echo "WHY3K テーマをインストールします"
echo

FILE="WHY3K Paper.ask"
SRC="$(pwd)/$FILE"
found=0
blocked=0

for app in /Applications/Ableton\ Live*.app; do
  [ -d "$app" ] || continue
  dir="$app/Contents/App-Resources/Themes"
  if [ ! -d "$dir" ]; then
    echo "スキップ（Themes フォルダなし）: $(basename "$app")"
    continue
  fi

  if cp "$FILE" "$dir/" 2>/dev/null; then
    echo "OK: $(basename "$app")"
    found=$((found + 1))
    continue
  fi

  # cp が macOS に止められた場合は Finder 経由でやり直す。
  # Finder からだと「アプリを変更する許可」のダイアログが出るので、許可すれば通る。
  echo "…$(basename "$app") は直接コピーを止められたので Finder 経由で試します（許可を求められたら許可してください）"
  if osascript -e "tell application \"Finder\" to duplicate (POSIX file \"$SRC\" as alias) to (POSIX file \"$dir\" as alias) with replacing" >/dev/null 2>&1; then
    echo "OK（Finder 経由）: $(basename "$app")"
    found=$((found + 1))
  else
    echo "失敗: $(basename "$app")"
    blocked=$((blocked + 1))
  fi
done

echo
if [ "$found" -gt 0 ]; then
  echo "完了。Live を再起動して、環境設定 > Theme & Colors > テーマ から"
  echo "「WHY3K Paper」を選んでください。"
fi

if [ "$blocked" -gt 0 ]; then
  cat <<'EOS'

自動コピーができなかったものがあります。手でやれば確実に入ります：

  1. このフォルダの「WHY3K Paper.ask」を Cmd+C でコピー
  2. /Applications の Ableton Live を右クリック > パッケージの内容を表示
  3. Contents > App-Resources > Themes を開く
  4. Cmd+V で貼り付け（許可を求められたら許可 / Touch ID かパスワード）
  5. Live を再起動して 環境設定 > Theme & Colors > テーマ から選ぶ
EOS
fi

if [ "$found" -eq 0 ] && [ "$blocked" -eq 0 ]; then
  echo "Ableton Live が /Applications に見つかりませんでした。"
fi

echo
echo "このウィンドウは閉じて大丈夫です。"
